call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
@echo off
call CL.exe /std:c++20 *.cpp /Fe:%1 > err.log 2>&1
@echo nul > compile"%ERRORLEVEL%"
del *.obj