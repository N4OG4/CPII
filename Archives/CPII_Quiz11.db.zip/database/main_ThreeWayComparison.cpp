#include <iostream>
#include <format>
#include <sstream>
#include "PokerCard.h"

using namespace std;

template<>
struct std::formatter<PokerCard, char>
{
    bool quoted = false;

    template<class ParseContext>
    constexpr ParseContext::iterator parse(ParseContext& ctx)
    {
        auto it = ctx.begin();
        if (it == ctx.end())
            return it;

        if (*it == '#')
        {
            quoted = true;
            ++it;
        }
        if (it != ctx.end() && *it != '}')
            throw std::format_error("Invalid format args for QuotableString.");

        return it;
    }

    template<class FmtContext>
    FmtContext::iterator format(PokerCard s, FmtContext& ctx) const
    {
        std::ostringstream out;
        if (quoted)
            out << "\"" << s << "\"";
        else
            out << s;

        return std::ranges::copy(std::move(out).str(), ctx.out()).out;
    }
};

int main()
{
    PokerCard pokerCard1, pokerCard2;
    cin >> pokerCard1 >> pokerCard2;
    while ( cin.good() )
    {
        if ( pokerCard1 > pokerCard2 )
        {
//            cout << pokerCard1 << " is less than " << pokerCard2 << endl;
            cout << format("{} is greater than {}.", pokerCard1, pokerCard2) << endl;
        }

        if ( pokerCard1 < pokerCard2 )
        {
//            cout << pokerCard1 << " is greater than " << pokerCard2 << endl;
            cout << format("{} is less than {}.", pokerCard1, pokerCard2) << endl;
        }

        if ( pokerCard1 == pokerCard2 )
        {
//            cout << pokerCard1 << " is equal to " << pokerCard2 << endl;
            cout << format("{} is equal to {}.", pokerCard1, pokerCard2) << endl;
        }

        cin >> pokerCard1 >> pokerCard2;
    }

    return 0;
}
