#include <iostream>
#include "NQueens.h"

using namespace std;

int main()
{
    size_t nQueens{0};
    cin >> nQueens;

    NQueens maxQueensObj{};
    while( nQueens > 0 )
    {
        NQueens nQueensObj{nQueens};
        nQueensObj.input().calculateAttacks().output();

        if ( maxQueensObj.size() < nQueensObj.size() )
        {
            maxQueensObj = nQueensObj;
        }

        cin >> nQueens;
    }

    constexpr size_t maxIteration{1'000'000L};
    for ( size_t i = 0; i < maxIteration; ++i )
    {
        NQueens tempObj(maxQueensObj);
    }

    return 0;
}
