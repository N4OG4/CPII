#include <iostream>
#include "TravelingSalesmanProblem.h"

using namespace std;

int main()
{
    TravelingSalesmanProblem tspObject;
    while ( !tspObject.input().badAlloc() )
    {
        tspObject.output();
    }

    return 0;
}
