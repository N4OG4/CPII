#include <iostream>
#include "TimeAndDate.h"

using namespace std;

int main()
{
    unsigned long int seed(0);
    while ( cin >> seed )
    {
        TimeAndDate tad(seed);
        tad.print();
    }

    return 0;
}
