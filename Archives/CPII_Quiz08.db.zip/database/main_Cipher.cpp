#include <format>
#include <iostream>
#include <ranges>
#include <string>
#include "cipher.h"

using namespace std;

int main()
{
    Cipher cipher;
    for ( const int& i : ranges::iota_view{0, 100} )
    {
        string secretKey;
        getline(cin, secretKey);
        string cipherText;
        getline(cin, cipherText);
        string plainText{cipher.decrypt(cipherText, secretKey)};
        cout << plainText << endl;
    }
}

