#include <iostream>
#include "EightQueens.h"

using namespace std;

int main()
{
    EightQueens eightQueens;
    for(unsigned int t = 0; t < 500; ++t)
    {
        input(eightQueens);
        eightQueens.calculateAttack();
        output(eightQueens);
    }

    return 0;
}
