#include <iostream>
#include "pattern_analysis.h"

using namespace std;

int main()
{
    Pattern_analysis test_obj;
    test_obj = Pattern_analysis(string{"1\t2\t3\t4"}, string{"\t"}, string{","});
    cout << test_obj.apply() << endl;

    string source;
    string pattern;
    string replacement;

	getline(cin, pattern);

    while( pattern.at(0) != '*' )
    {
		getline(cin, replacement);
		getline(cin, source);

        Pattern_analysis pattern_analysis_obj{source, pattern, replacement};
		cout << pattern_analysis_obj.apply() << endl;

		getline(cin, pattern);
    }

    return 0;
}
