#include <iostream>
#include <iomanip>
#include <string>
#include <format>
#include <sstream>
#include "myString.h"

void displayMyString(const MyString &mystring)
{
    std::stringstream ss;
    ss << std::quoted(mystring.get_string());
    std::cout << format("{} gets {}.", ss.str(), mystring.compact_sum() ) << std::endl;
}

int main()
{
    MyString str1{};
    displayMyString(str1);

    MyString str2{"ABCDEF"};
    displayMyString(str2);

    char char_array[] = "zyxwvuts";
    MyString str3{char_array};
    displayMyString(str3);

	std::string input{};
	while ( getline(std::cin, input).good() )
    {
        str3.set_string(input);
        displayMyString(str3);
    }

    return 0;
}
