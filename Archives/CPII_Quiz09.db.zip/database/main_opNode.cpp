#include <iostream>
#include <vector>
#include "opNode.h"

using namespace std;

int main()
{
    const size_t numInput = 1000;
    vector<int> opState(numInput);

    for ( int &c : opState )
    {
        cin >> c;
    }

    vector<OpNode*> opNodeVector(numInput);
    size_t n = 0;
    for ( OpNode* &opNodePtr : opNodeVector )
    {
        switch(opState[n++])
        {
        case 0:
            opNodePtr = new AddNode;
            break;
        case 1:
            opNodePtr = new SubNode;
            break;
        case 2:
            opNodePtr = new MulNode;
            break;
        case 3:
            opNodePtr = new DivNode;
            break;
        case 4:
            opNodePtr = new ModNode;
            break;
        case 5:
            opNodePtr = new AndNode;
            break;
        case 6:
            opNodePtr = new OrNode;
            break;
        case 7:
            opNodePtr = new NotNode;
            break;
        case 8:
            opNodePtr = new NegNode;
            break;
        default:
            cerr << "Error Operator State" << endl;
            break;
        }
    }

    for ( OpNode* opNodePtr : opNodeVector )
    {
        opNodePtr->input()->output();
    }

    for ( OpNode* &opNodePtr : opNodeVector )
    {
        delete opNodePtr;
    }

    return 0;
}
