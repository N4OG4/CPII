#include <iostream>
#include <format>
#include <string>
#include "employee.h"

using namespace std;

int main()
{
    string input;
    getline(cin, input);

    while ( cin.good() )
    {
        Employee employee{input};
        cout << employee.info() << endl;

        getline(cin, input);
    }

    return 0;
}
